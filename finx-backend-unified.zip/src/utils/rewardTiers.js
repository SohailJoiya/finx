module.exports = [
  { tier: 'Bronze',   target: 1000,  reward: 50 },
  { tier: 'Silver',   target: 5000,  reward: 300 },
  { tier: 'Gold',     target: 10000, reward: 700 },
  { tier: 'Platinum', target: 20000, reward: 1500 },
];